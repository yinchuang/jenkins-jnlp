## PKCS #11 Cryptographic Token Interface v2.20 Amendment 3 Header Files

### PKCS #11 Cryptographic Token Interface License
<pre>

License to copy and use this software is granted provided that it is
identified as "RSA Security Inc. PKCS #11 Cryptographic Token Interface
(Cryptoki)" in all material mentioning or referencing this software.

License is also granted to make and use derivative works provided that
such works are identified as "derived from the RSA Security Inc. PKCS #11
Cryptographic Token Interface (Cryptoki)" in all material mentioning or
referencing the derived work.

RSA Security Inc. makes no representations concerning either the
merchantability of this software or the suitability of this software for
any particular purpose. It is provided "as is" without express or implied
warranty of any kind.

</pre>
